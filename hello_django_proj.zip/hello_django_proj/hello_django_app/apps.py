from django.apps import AppConfig


class HelloDjangoAppConfig(AppConfig):
    name = 'hello_django_app'
